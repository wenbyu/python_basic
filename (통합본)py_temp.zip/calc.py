# 사용자정의 함수의 이해
def 더하기_n(x,y) :
    return print(f'{x} + {y} = {x+y} 입니다')

def 빼기_n(x,y) :
    return print(f'{x} - {y} = {x-y} 입니다')

def 곱하기_n(x,y) :
    return print(f'{x} * {y} = {x*y} 입니다')

def 나누기_n(x,y) :
    return print(f'{x} / {y} = {x/y} 입니다')
